"""W0333: flag backtick as deprecated"""

__revision__ = None
print `1`
